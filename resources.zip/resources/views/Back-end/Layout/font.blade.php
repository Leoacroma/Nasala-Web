<style>
    .notify-message{
      z-index: 10000000;
    }
    /*Khmer font*/
    @font-face{
      font-family: 'Hanuman', serif;
      src: url('https://fonts.googleapis.com/css2?family=Hanuman:wght@100&display=swap');
    }
    @font-face{
      font-family: 'Battambang', cursive;
      src: url('https://fonts.googleapis.com/css2?family=Battambang:wght@100&display=swap');
    }
    @font-face{
      font-family: 'Siemreap', cursive;
      src: url('https://fonts.googleapis.com/css2?family=Siemreap&display=swap'); 
    }
    @font-face{
      font-family: 'Moul', cursive;
      src: url('https://fonts.googleapis.com/css2?family=Moul&display=swap');
    }
    @font-face{
      font-family: 'Preahvihear', sans-serif;
      src: url('https://fonts.googleapis.com/css2?family=Preahvihear&display=swap');
    }
    @font-face{
      font-family: 'Koulen', cursive;
      src: url('https://fonts.googleapis.com/css2?family=Koulen&display=swap');
    }
    @font-face{
      font-family: 'Kantumruy Pro', sans-serif;
      src: url('https://fonts.googleapis.com/css2?family=Kantumruy+Pro:wght@100&display=swap');
    }
    /*English-font*/
    @font-face{
       font-family: 'Roboto', sans-serif;
      src: url('https://fonts.googleapis.com/css2?family=Roboto:wght@100&display=swap');
    }
    @font-face{
      font-family: 'Open Sans', sans-serif;
      src: url('https://fonts.googleapis.com/css2?family=Open+Sans:wght@300&display=swap');
    }
    @font-face{
      font-family: 'Ubuntu', sans-serif;
      src: url('https://fonts.googleapis.com/css2?family=Ubuntu:wght@300&display=swap');
    }
    @font-face{
        font-family: 'Merriweather', serif;
      src: url('https://fonts.googleapis.com/css2?family=Merriweather:wght@300&display=swap');
    }
    @font-face{
     font-family: 'PT Sans', sans-serif;
      src: url('https://fonts.googleapis.com/css2?family=PT+Sans&display=swap');
    }
  </style>