@extends('Back-end.Layout.index')
@section('template')
      <!-- partial -->
  <div class="container-fluid page-body-wrapper">
    <div class="main-panel">
      <div class="content-wrapper">
        <div class="row">
          <div class="col-lay-10 grid-margin stretch-card">
            <div class="card">
              <div class="card-body">
                <h2 class="card-title ">Page</h2>
                <p class="card-description Siemreap">
                  Create page
                </p>
                <div class="divider-line"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
</div>
@endsection